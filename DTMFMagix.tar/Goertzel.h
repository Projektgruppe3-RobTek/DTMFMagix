float doGoertzel(int sampleRate/*Rate the signal is sampled at*/, float targetFreq/*The frequency to find the applitude at*/, std::vector<float> &samples/*The samples*/);
